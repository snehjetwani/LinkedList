class Main {
  public static void main(String[] args) {
    //Create Java class LinkedList.java and write your code there.
   LinkedList list = new LinkedList();
    list.add("One");  
    list.add("Two");  
    list.add("Three");  
    list.add("Four");  
    System.out.println(list);
    list.reverse();
    System.out.println(list);
  }
}