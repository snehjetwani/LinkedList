public class LinkedList{
  private class Node{
    protected Node next;
    protected Node previous;
    protected String value;
    public Node(){
      
    }
    public Node(String value){
      this.value = value;
    }
  }
  private Node first;
  private Node last;
//Appends the specified element to the end of the list.
  public void add(String element){
    //creating new node
    Node myNode = new Node(element);
    myNode.next = null;
    myNode.previous = null;
//make the node first if the list is empty
    if(first == null){
      first = myNode;
    }
    else{
      //making a searcher node to find end of list
      Node searcher = new Node();
      searcher = first;
      while(searcher.next != null){
        searcher = searcher.next;
      }
      //when the last element has been reached, place node next
      searcher.next = myNode;
    }
  }
  //Inserts the specified element at the specified position in the list
  public void add(int index, String element){
    //creating a node
    Node myNode = new Node(element);
    //if list is empty, make node the first element
    if(index == 0){
      myNode.next = first;
      first.previous = myNode;
      first = myNode;
    }
    else{
      //making a searcher node to find specified index
      Node searcher = new Node();
      searcher = first;
      //traverse list until searcher reaches index - 1 spot
      for(int i = 0; i<index - 1; i++){
        searcher = searcher.next;
        //handling null pointer exception error
        if(searcher == null){
          return;
        }
      }
      searcher.next = myNode;
    }
    }
  //Removes all of the elements from the list
  public void clear(){
    //creating node
    Node myNode = new Node();
    //making the first element of each iteration null until list is cleared
    while(first != null){
      myNode = first;
      first = first.next;
      myNode = null;
    }
  }
  //Returns the element at the specified position in the list. Return empty string if the index is "out of bounds".
  public String get(int index){
    //out of bounds returns empty string
    if(index < 0){
      return " ";
    }
    else{
      //creating node
    Node myNode = new Node();
    myNode = first;
      //current index value
    int current = 0;
  //while myNode is not at the end, traverse through list
    while(myNode != null){
      //when current = index, return value of element at current
      if(current == index){
        return myNode.value;
      }
      //keep increasing current index till end of list
      current++;
      myNode = myNode.next;
    }
      //out of bounds exception handler
    return " ";
    }
  }
  //Sets the element at the specified position in the list to the given value.
  public void set(int index, String element){
    //do nothing if out of bounds
    if(index < 0){

    }
    else{
      //creating node
      Node myNode = new Node();
      myNode = first;
      //current index value
      int current = 0;
      //while myNode is not at the end, traverse through list
      while(myNode != null){
        //when the current index reaches the target index, set its value equal to element
        if(current == index){
          myNode.value = element;
        }
        //increase current counter
        current++;
        myNode = myNode.next;
      }
    }
  }
  //Removes the element at the specified position in the list.
  public void remove(int index){
    //do nothing if index is out of bounds
    if(index < 0){
      
    }
      //if the first element is being removed
    else if(index == 0 && first != null){
      //set the first element = null
      Node remove = new Node();
      remove = first;
      first = first.next;
      remove = null;
    }
    else{
      //creating searcher node
      Node searcher = new Node();
      searcher = first;
      //traverse through array until index - 1 is found
      for(int i = 1; i<= index - 1; i++){
        if(searcher != null){
          searcher = searcher.next;
        }
      }
      //removing the element at selected index
      if(searcher != null && searcher.next != null){
        Node remove = searcher.next;
        searcher.next = searcher.next.next;
        remove = null;
      }
    }
  }
  //Removes the FIRST occurrence of the specified element
  public void remove(String element){
    //creating node
    Node myNode = new Node();
    myNode = first;
  // remove element if it's first in the list
    if(myNode != null && myNode.value == element){
      Node remove = new Node();
      remove = first;
      first = first.next;
      remove = null;
    }
    else{
      while(myNode.next != null){
        //traverses through list and removes first occurence of element
        if(myNode.next.value == element){
          Node remove = myNode.next;
          myNode.next = myNode.next.next;
          remove = null;
        }
        myNode = myNode.next;
      }
    }
  }
  //Returns the number of elements in this list
  public int size(){
    //creating node
    Node myNode = new Node();
    myNode = first;
    //initializing counter
    int counter = 0;
    //loops through list counting nodes that aren't null
    while(myNode != null){
      counter++;
      myNode = myNode.next;
    }
// return number of elements
    return counter;
  }

  //Dynamic Data Structures Final
  
  //Reverse the linked list
  public void reverse(){
    Node currentNode = first;
    Node previousNode = null;
    Node nextNode = null;

    while (currentNode != null) {
        nextNode = currentNode.next;
        currentNode.next = previousNode;
        previousNode = currentNode;
        currentNode = nextNode;
    }
    
    first = previousNode;
}
  //Convert list to a string
  public String toString(){
    //creating a new node
    Node myNode = new Node();
    myNode = first;
    //empty string to store elements
    String list = "";
    //if there are elements, add a "List: " to empty string
    if(myNode != null){
      list += "List: ";
      //while myNode isn't null, add the value of the myNode to the string, and set myNode equal to the next node in the list. Then, keep looping until the end of the list
      while(myNode != null){
        list += myNode.value + " ";
        myNode = myNode.next;
      }
    }
      //nothing in the list
    else{
      list += "Empty List :(";
    }
    return list;
  }
}